<?php


    // $a= $_SESSION['username'];
    
    echo "<li class=\"nav-item\">";
    echo "<a class=\"nav-link\" href=\"./code manager/index.php\">Manager</a>";
    echo "</li>";



?>