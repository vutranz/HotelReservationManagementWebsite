<?php
    echo "<li class=\"nav-item\">";
    echo "<a class=\"nav-link\" href=\"manager-history.php\">HistoryBookRoom</a>";
    echo "</li>";

?>